import java.awt.*;
import java.applet.*;

public class Face1 extends Applet{
	public void paint(Graphics g){
		g.drawOval(510,294,143,137);
		g.drawOval(468,350,40,43);
		g.drawOval(651,358,40,43);
		g.drawOval(543,331,26,27);
		g.drawOval(605,343,26,27);
		
	}
}