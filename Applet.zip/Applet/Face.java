import java.awt.*;
import java.applet.*;

public class Face extends Applet{
	public void paint(Graphics g){
		g.drawOval(409,300,226,140);
		g.drawOval(370,350,41,56);
		g.drawOval(634,363,41,56);
		g.drawLine(521,364,521,418);
		g.setColor(Color.black);
		g.fillOval(464,345,29,25);
		g.fillOval(558,350,29,25);
		g.drawArc(490,407,69,15,0,-180);
		g.drawArc(457,322,44,20,0,180);
		g.drawArc(548,318,44,20,0,180);
	}
	
}