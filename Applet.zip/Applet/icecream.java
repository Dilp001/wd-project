import java.awt.*;
import java.applet.*;

public class icecream extends Applet{
	int x[]={424,526,628};
	int y[]={327,553,328};
	public void paint(Graphics g){
		g.drawPolygon(x,y,3);
		g.drawOval(490,174,68,58);
		g.drawArc(422,234,206,200,0,180);
		
	}
}