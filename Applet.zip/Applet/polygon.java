import java.awt.*;
import java.applet.*;

public class polygon extends Applet{
	int x[]={851,1008,924};
	int y[]={347,346,507};
	
public void paint(Graphics g){
	g.drawPolygon(x,y,3);
	//g.drawArc(281,315,266,149,0,180);
	}
}
