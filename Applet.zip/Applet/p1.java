import java.awt.*;
import java.applet.*;

public class p1 extends Applet{
	int x[]={543,396,688};
	int y[]={243,392,391};
	public void paint(Graphics g){
		g.drawRect(399,393,291,169);
		g.drawRect(499,470,103,91);
		g.drawPolygon(x,y,3);
		g.drawLine(543,243,539,88);
		g.drawRect(539,88,100,100);
		
		
	}
}