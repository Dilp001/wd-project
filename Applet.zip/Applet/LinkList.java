public class LinkList{
	public class Node{
		int data;
		Node next;
		
			public Node(int data){
				this.data=data;
				this.next=null;
				
			}	
			
		}
	public static Node head;
	public static Node tail;
	public static int size;
	
	
	public void addFirst(int data){
		Node newnode=new Node(data);
			size++;
		if(head==null){
			head=tail=newnode;
			return;
		}
		newnode.next=head;
		head=newnode;
	}
	
	public void addLast(int data){
		Node newnode=new Node(data);
			size++;
		if(head==null){
			head=tail=newnode;
			return;
		}
		tail.next=newnode;
		tail=newnode;
	}
	
	public void add(int idx,int data){
		Node newnode=new Node(data);
			size++;
		if(idx==0){
			addFirst(data);
			return;
		}
		Node temp=head;
		int i=0;
		while(i<idx-1){
			temp=temp.next;
			i++;
		}
		newnode.next=temp.next;
		temp.next=newnode;
		
	}
	
	public void removeFirst(){
		if(size==0){
			System.out.print("LinkList is Empty");
			return;

		}
		else if(size==1){
			head=tail=null;
			size=0;
			return;
		}
		head=head.next;
		size--;
	}
	
	public void removeLast(){
		if(size==0){
			System.out.print("LinkList is Empty");
			return;

		}
		else if(size==1){
			head=tail=null;
			size=0;
			return;
		}
		Node temp=head;
		
		for(int i=0;i<size-2;i++){
			temp=temp.next;
			return;
		}
		
		temp.next=null;
		tail=temp;
		size--;
		
	}

	
	public void print(){
		Node temp=head;
		while(temp!=null){
			System.out.print(temp.data+"-->");
			temp=temp.next;
		}
		
		System.out.println("Null");
		
	}

	
	public static void main(String[] args){
		LinkList ll=new LinkList();
		ll.addFirst(2);
		ll.addFirst(1);
		ll.addFirst(0);
		ll.addLast(4);
		ll.addLast(5);
		ll.addLast(6);
		ll.add(3,3);
		ll.removeFirst();
		ll.removeLast();
		ll.print();
		System.out.println("Size of LinkList:"+size);
			
	}
	
}