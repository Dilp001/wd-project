﻿Imports System.Data.OleDb
Public Class StudMast
    Dim ds As New DataSet
    Dim maxrow, inc As Integer
    Dim gender As String = ""
    Dim s1 As New Student
    Dim cm As OleDbCommand

    Private Sub StudMast_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'Disconnected(Model)
        ds = s1.Display("select * from CourseMast")
        cmbCourse.DataSource = ds.Tables(0)

        cmbCourse.DisplayMember = "CourseName"
        cmbCourse.ValueMember = "CourseId"

        FillStudentData()

        'Connected(Model)
        'Dim dr As New OleDbDataReader
        'cm = New OleDbCommand("select * from CourseMast", cn)
        'cn.Open()
        'dr = cm.ExecuteReader()
        'If dr.HasRows = True Then
        '    While dr.Read
        '       cmbCourse.Items.Add(dr.Item("CourseName").ToString)
        '    End While
        'End If
        'dr.Close()
        'cn.Close()
    End Sub

    Private Sub FillStudentData()
        ds = s1.Display("select s.SID,s.RNo,s.SName,s.Address,s.Phone,s.Email,s.Gender,c.CourseName from Student s,CourseMast c where c.CourseId=s.CourseId order by RNo")
        DataGridView1.DataSource = ds.Tables(0)

        DataGridView1.Columns(0).Visible = False
        maxrow = ds.Tables(0).Rows.Count
    End Sub

    Private Sub btnInsert_Click(sender As System.Object, e As System.EventArgs) Handles btnInsert.Click
        If rbMale.Checked = True Then
            gender = "Male"
        ElseIf rbFemale.Checked = True Then
            gender = "Female"
        End If

        'cm = New OleDbCommand("Insert into student values(@p1,@p2,@p3,@p4,@p5,@p6,@p7)", cn)

        'Dim c1 As New OleDbParameter
        'c1.ParameterName = "@p1"
        'c1.OleDbType = OleDbType.Numeric
        'c1.Value = txtRNo.Text
        'cm.Parameters.Add(c1)

        'cm.Parameters.Add("@p1", OleDbType.Numeric).Value = txtRNo.Text
        'cm.Parameters.Add("@p2", OleDbType.VarChar).Value = txtName.Text
        'cm.Parameters.Add("@p3", OleDbType.VarChar).Value = txtAdd.Text
        'cm.Parameters.Add("@p4", OleDbType.VarChar).Value = txtPhone.Text
        'cm.Parameters.Add("@p5", OleDbType.VarChar).Value = txtEmail.Text
        'cm.Parameters.Add("@p6", OleDbType.VarChar).Value = gender
        'cm.Parameters.Add("@p7", OleDbType.Numeric).Value = cmbCourse.SelectedValue


        s1.IUD("Insert into Student(RNo,SName,Address,Phone,Email,Gender,CourseID) values(" & txtRNo.Text & ",'" & txtName.Text & "','" & txtAdd.Text & "','" & txtPhone.Text & "','" & txtEmail.Text & "','" & gender & "'," & cmbCourse.SelectedValue & ")")

        FillStudentData()
        clearControls()
    End Sub

    Private Sub btnUpdate_Click(sender As System.Object, e As System.EventArgs) Handles btnUpdate.Click
        If rbMale.Checked = True Then
            gender = "Male"
        ElseIf rbFemale.Checked = True Then
            gender = "Female"
        End If

        s1.IUD("Update Student set SName='" & txtName.Text & "',Address='" & txtAdd.Text & "',Phone='" & txtPhone.Text & "',Email='" & txtEmail.Text & "',Gender='" & gender & "',CourseId=" & cmbCourse.SelectedValue & " where SID=" & txtSID.Text)
        FillStudentData()
        clearControls()
    End Sub

    Private Sub btnDelete_Click(sender As System.Object, e As System.EventArgs) Handles btnDelete.Click
        s1.IUD("Delete from Student where SID=" & txtSID.Text)
        FillStudentData()
        clearControls()
    End Sub

    Private Sub btnExit_Click(sender As System.Object, e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnFilter_Click(sender As System.Object, e As System.EventArgs) Handles btnFilter.Click
        FilterData.Show()
    End Sub

    Private Sub DisplayRecord()
        txtRNo.Text = ds.Tables(0).Rows(inc).Item(1)
        txtName.Text = ds.Tables(0).Rows(inc).Item(2)
        txtAdd.Text = ds.Tables(0).Rows(inc).Item(3)
        txtPhone.Text = ds.Tables(0).Rows(inc).Item(4)
        txtEmail.Text = ds.Tables(0).Rows(inc).Item(5)
        Dim gender As String = ds.Tables(0).Rows(inc).Item(6)
        If gender = "Male" Then
            rbMale.Checked = True
        ElseIf gender = "Female" Then
            rbFemale.Checked = True
        End If
        cmbCourse.Text = ds.Tables(0).Rows(inc).Item(7)
    End Sub

    Private Sub btnFirst_Click(sender As System.Object, e As System.EventArgs) Handles btnFirst.Click
        inc = 0
        DisplayRecord()
    End Sub

    Private Sub btnLast_Click(sender As System.Object, e As System.EventArgs) Handles btnLast.Click
        inc = maxrow - 1
        DisplayRecord()
    End Sub

    Private Sub btnPrevious_Click(sender As System.Object, e As System.EventArgs) Handles btnPrevious.Click
        If inc = 0 Then
            MessageBox.Show("First Rec...")
        Else
            inc -= 1
            DisplayRecord()
        End If
    End Sub

    Private Sub btnNext_Click(sender As System.Object, e As System.EventArgs) Handles btnNext.Click
        If inc = maxrow - 1 Then
            MessageBox.Show("Last Rec...")
        Else
            inc += 1
            DisplayRecord()
        End If
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        inc = e.RowIndex
        txtRNo.Enabled = False
        txtSID.Text = DataGridView1.Rows(inc).Cells(0).Value
        txtRNo.Text = DataGridView1.Rows(inc).Cells(1).Value
        txtName.Text = DataGridView1.Rows(inc).Cells(2).Value
        txtAdd.Text = DataGridView1.Rows(inc).Cells(3).Value
        txtPhone.Text = DataGridView1.Rows(inc).Cells(4).Value
        txtEmail.Text = DataGridView1.Rows(inc).Cells(5).Value
        gender = DataGridView1.Rows(inc).Cells(6).Value
        If gender = "Male" Then
            rbMale.Checked = True
        ElseIf gender = "Female" Then
            rbFemale.Checked = True
        End If
        cmbCourse.Text = DataGridView1.Rows(inc).Cells(7).Value

    End Sub

    Private Sub btnAsc_Click(sender As System.Object, e As System.EventArgs) Handles btnAsc.Click
        Dim oview As New DataView(ds.Tables(0))
        oview.Sort = "RNo asc"
        DataGridView1.DataSource = oview
    End Sub

    Private Sub btnDesc_Click(sender As System.Object, e As System.EventArgs) Handles btnDesc.Click
        Dim oview As New DataView(ds.Tables(0))
        oview.Sort = "RNo desc"
        DataGridView1.DataSource = oview
    End Sub

    Private Sub clearControls()
        txtRNo.Text = ""
        txtRNo.Enabled = True
        txtName.Text = ""
        txtAdd.Text = ""
        txtPhone.Text = ""
        txtEmail.Text = ""
        rbMale.Checked = False
        rbFemale.Checked = False
        cmbCourse.Text = ""
    End Sub
End Class

