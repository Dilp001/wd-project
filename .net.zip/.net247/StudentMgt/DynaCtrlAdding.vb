﻿Public Class DynaCtrlAdding
    Dim lbl(1) As Label
    Dim txt As New TextBox
    Dim chk(3) As CheckBox
    Dim btn As New Button

    Private Sub DynaCtrlAdding_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Dim top As Integer = 30
        Dim left As Integer = 30

        lbl(0) = New Label
        lbl(0).Top = top
        lbl(0).Left = left
        lbl(0).Text = "Student Name"
        Me.Controls.Add(lbl(0))

        txt.Top = top
        txt.Left = left + 100
        Me.Controls.Add(txt)

        top += 30
        lbl(1) = New Label
        lbl(1).Top = top
        lbl(1).Left = left
        lbl(1).Text = "Division"
        Me.Controls.Add(lbl(1))

        For i As Integer = 0 To 3
            chk(i) = New CheckBox
            chk(i).Top = top
            chk(i).Left = left + 100
            chk(i).Text = "FY-" & i + 1
            Me.Controls.Add(chk(i))
            top += 30
        Next

        btn.Top = top
        btn.Left = left + 100
        'btn.Text = "Add"
        btn.Height = "150"
        btn.Width = "200"
        btn.Image = Image.FromFile("C:\Users\LENOVO PC\Desktop\sweety\VB.Net\StudentMgtSystem\Penguins.jpg")
        Me.Controls.Add(btn)
        AddHandler btn.Click, AddressOf xxx
    End Sub

    Private Sub xxx()
        MessageBox.Show("Hiiiii")
    End Sub

    Private Sub btnClick_Click(sender As System.Object, e As System.EventArgs) Handles btnClick.Click
        Me.Controls.Remove(btn)
        btn.Dispose()
    End Sub
End Class