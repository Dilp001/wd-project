﻿Public Class FilterData
    Dim s1 As New Student
    Dim ds As New DataSet

    Private Sub FilterData_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ds = s1.Display("select * from CourseMast")
        cmbCourse.DataSource = ds.Tables(0)

        cmbCourse.DisplayMember = "CourseName"
        cmbCourse.ValueMember = "CourseId"

    End Sub

    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        ds = s1.Display("select s.RNo,s.SName,s.Address,s.Phone,s.Email,s.Gender,c.CourseName from Student s,CourseMast c where c.CourseId=s.CourseId and SName like '" & txtSName.Text & "%' and c.CourseId = " & cmbCourse.SelectedValue & " order by RNo")
        DataGridView1.DataSource = ds.Tables(0)

        'and SName Like 'AA%' ORDER BY RNO
    End Sub

End Class