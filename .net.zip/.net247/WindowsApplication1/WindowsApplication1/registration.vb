﻿Public Class registration

    Private Sub btnreg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreg.Click
        If txtPwd.Text <> txtCpwd.Text Then
            MessageBox.Show("Password and cpwd doesnt match")
            Exit Sub
        End If
        lblMsg.Text = "Name:" & txtName.Text & vbCrLf & "Address:" & txtAdd.Text & vbCrLf & "Phone:" & txtPhone.Text & vbCrLf & "Email:" & txtEmail.Text & vbCrLf

        If rbMale.Checked = True Then
            lblMsg.Text += "Gender:" & rbMale.Text & vbCrLf & "Hobbies:"
        ElseIf rbFemale.Checked = True Then
            lblMsg.Text += "gender:" & rbFemale.Text & vbCrLf & "hobbies:"
        End If

        For Each item In ChkHobbies.CheckedItems
            lblMsg.Text += item & ""

        Next

    End Sub
End Class