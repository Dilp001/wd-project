﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SimpleCalc
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnSub = New System.Windows.Forms.Button()
        Me.btnMul = New System.Windows.Forms.Button()
        Me.btnDiv = New System.Windows.Forms.Button()
        Me.txtno1 = New System.Windows.Forms.TextBox()
        Me.txtno2 = New System.Windows.Forms.TextBox()
        Me.txtans = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(35, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "No.1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(36, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(30, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "No.2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(35, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Ans :"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(41, 119)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(92, 23)
        Me.btnAdd.TabIndex = 3
        Me.btnAdd.Text = "Addition"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'btnSub
        '
        Me.btnSub.Location = New System.Drawing.Point(163, 118)
        Me.btnSub.Name = "btnSub"
        Me.btnSub.Size = New System.Drawing.Size(90, 23)
        Me.btnSub.TabIndex = 4
        Me.btnSub.Text = "Substraction"
        Me.btnSub.UseVisualStyleBackColor = True
        '
        'btnMul
        '
        Me.btnMul.Location = New System.Drawing.Point(41, 170)
        Me.btnMul.Name = "btnMul"
        Me.btnMul.Size = New System.Drawing.Size(92, 23)
        Me.btnMul.TabIndex = 5
        Me.btnMul.Text = "Multiplication"
        Me.btnMul.UseVisualStyleBackColor = True
        '
        'btnDiv
        '
        Me.btnDiv.Location = New System.Drawing.Point(163, 170)
        Me.btnDiv.Name = "btnDiv"
        Me.btnDiv.Size = New System.Drawing.Size(90, 23)
        Me.btnDiv.TabIndex = 6
        Me.btnDiv.Text = "Division"
        Me.btnDiv.UseVisualStyleBackColor = True
        '
        'txtno1
        '
        Me.txtno1.Location = New System.Drawing.Point(72, 26)
        Me.txtno1.Name = "txtno1"
        Me.txtno1.Size = New System.Drawing.Size(100, 20)
        Me.txtno1.TabIndex = 7
        '
        'txtno2
        '
        Me.txtno2.Location = New System.Drawing.Point(72, 52)
        Me.txtno2.Name = "txtno2"
        Me.txtno2.Size = New System.Drawing.Size(100, 20)
        Me.txtno2.TabIndex = 8
        '
        'txtans
        '
        Me.txtans.Location = New System.Drawing.Point(72, 83)
        Me.txtans.Name = "txtans"
        Me.txtans.Size = New System.Drawing.Size(100, 20)
        Me.txtans.TabIndex = 9
        '
        'SimpleCalc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.txtans)
        Me.Controls.Add(Me.txtno2)
        Me.Controls.Add(Me.txtno1)
        Me.Controls.Add(Me.btnDiv)
        Me.Controls.Add(Me.btnMul)
        Me.Controls.Add(Me.btnSub)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "SimpleCalc"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnSub As System.Windows.Forms.Button
    Friend WithEvents btnMul As System.Windows.Forms.Button
    Friend WithEvents btnDiv As System.Windows.Forms.Button
    Friend WithEvents txtno1 As System.Windows.Forms.TextBox
    Friend WithEvents txtno2 As System.Windows.Forms.TextBox
    Friend WithEvents txtans As System.Windows.Forms.TextBox

End Class
