﻿Public Class StudDetail
    Inherits Student

    Private ht As Single
    Private wt As Single

    Public Sub New(ByVal rno As Integer, ByVal name As String, ByVal ht As Single, ByVal wt As Single)
        MyBase.New(rno, name)
        Me.ht = ht
        Me.wt = wt
    End Sub

    Public Overrides Sub display()
        MessageBox.Show(pRollno & " " & pName & " " & ht & " " & wt)
    End Sub
End Class
