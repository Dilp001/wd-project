﻿Public Class SimpleCalc
    Dim a As Double = 0
    Dim b, ans As Double


    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        a = Convert.ToDouble(txtno1.Text)
        b = Convert.ToDouble(txtno2.Text)
        ans = a + b
        txtans.Text = ans
    End Sub

    Private Sub btnSub_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSub.Click
        a = Convert.ToDouble(txtno1.Text)
        b = Convert.ToDouble(txtno2.Text)
        txtans.Text = a - b
    End Sub

    Private Sub btnMul_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMul.Click
        txtans.Text = Convert.ToDouble(txtno1.Text) * Convert.ToDouble(txtno2.Text)
    End Sub

    Private Sub btnDiv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDiv.Click
        a = Convert.ToDouble(txtno1.Text)
        b = Convert.ToDouble(txtno2.Text)
        txtans.Text = a / b
    End Sub
End Class
