﻿Public Class MyClassEx
    Dim jaws As New Fish()

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        jaws.Live()
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        jaws.Live2()
    End Sub
End Class