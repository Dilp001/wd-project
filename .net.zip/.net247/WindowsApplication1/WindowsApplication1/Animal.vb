﻿Public Class Animal
    Sub Live()
        Breathing()
    End Sub
    Sub Live2()
        MyClass.Breathing()
    End Sub
    Overridable Sub Breathing()
        MsgBox("Breathing....")
    End Sub
End Class
