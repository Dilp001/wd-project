﻿Public Class ArrayCollectionEx

    Private Sub btnobjarr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnobjarr.Click
        Dim oarr(2) As Object
        Dim sarr() As String = {"Dance", "Music", "Singing"}
        oarr(0) = 101
        oarr(1) = "AAA"
        oarr(2) = sarr
        MessageBox.Show(oarr(0))
        MessageBox.Show(oarr(1))
        MessageBox.Show(oarr(2)(1))
    End Sub

    Private Sub btncollection_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncollection.Click
        Dim actors As New Collection
        actors.Add("Hritik", "HR")
        actors.Add("Sara Ali", 3.14)
        MessageBox.Show(actors.Item("HR"))
    End Sub
End Class