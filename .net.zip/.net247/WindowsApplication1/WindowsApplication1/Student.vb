﻿Public Class Student
    Private rno As Integer
    Private name As String

    Public Property pRollno() As Integer
        Get
            Return rno
        End Get
        Set(ByVal value As Integer)
            rno = value
        End Set
    End Property

    Public Property pName() As String
        Get
            Return name
        End Get
        Set(ByVal value As String)
            name = value
        End Set
    End Property

    Public Sub New()
        rno = 2
        name = "XYZ"
    End Sub

    Public Sub New(ByVal rno As Integer, ByVal name As String)
        Me.rno = rno
        Me.name = name
    End Sub

    Public Sub New(ByVal sobj As Student)
        rno = sobj.pRollno
        name = sobj.pName
    End Sub

    Overridable Sub display()

    End Sub
End Class
