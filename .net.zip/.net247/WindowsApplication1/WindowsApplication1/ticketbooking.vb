﻿Public Class ticketbooking

    Private Sub ticketbooking_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        rbWD.Checked = True
    End Sub

    Private Sub btnCal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCal.Click
        Dim total As Double = 0

        If rbWD.Checked = True Then
            total = total + 50
        ElseIf rbWE.Checked = True Then
            total = total + 100
        End If

        If chkDance.Checked = True Then
            total = total + 40
        End If

        If chkSing.Checked = True Then
            total = total + 50
        End If

        If chkGame.Checked = True Then
            total = total + 80
        End If

        If chkSports.Checked = True Then
            total = total + 90
        End If

        total = total * Convert.ToDouble(txtNooftickets.Text)
        txtTotal.Text = total

    End Sub
End Class