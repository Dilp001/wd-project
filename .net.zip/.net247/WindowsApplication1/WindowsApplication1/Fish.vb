﻿Public Class Fish
    Inherits Animal
    Public Overrides Sub Breathing()
        MsgBox("Bubbling....")
    End Sub
End Class
