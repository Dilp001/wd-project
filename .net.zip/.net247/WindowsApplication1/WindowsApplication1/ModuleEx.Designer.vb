﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ModuleEx
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnreverse = New System.Windows.Forms.Button()
        Me.btnpalindrom = New System.Windows.Forms.Button()
        Me.btndectobin = New System.Windows.Forms.Button()
        Me.txtStringno = New System.Windows.Forms.TextBox()
        Me.txtReversestr = New System.Windows.Forms.TextBox()
        Me.txtBin = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(28, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter String Number"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(28, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Reverse String"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Dec To Binary"
        '
        'btnreverse
        '
        Me.btnreverse.Location = New System.Drawing.Point(92, 150)
        Me.btnreverse.Name = "btnreverse"
        Me.btnreverse.Size = New System.Drawing.Size(75, 23)
        Me.btnreverse.TabIndex = 3
        Me.btnreverse.Text = "Reverse"
        Me.btnreverse.UseVisualStyleBackColor = True
        '
        'btnpalindrom
        '
        Me.btnpalindrom.Location = New System.Drawing.Point(73, 195)
        Me.btnpalindrom.Name = "btnpalindrom"
        Me.btnpalindrom.Size = New System.Drawing.Size(115, 23)
        Me.btnpalindrom.TabIndex = 4
        Me.btnpalindrom.Text = "Check Palindrom"
        Me.btnpalindrom.UseVisualStyleBackColor = True
        '
        'btndectobin
        '
        Me.btndectobin.Location = New System.Drawing.Point(73, 235)
        Me.btndectobin.Name = "btndectobin"
        Me.btndectobin.Size = New System.Drawing.Size(115, 23)
        Me.btndectobin.TabIndex = 5
        Me.btndectobin.Text = "Covert dec To Bin"
        Me.btndectobin.UseVisualStyleBackColor = True
        '
        'txtStringno
        '
        Me.txtStringno.Location = New System.Drawing.Point(136, 37)
        Me.txtStringno.Name = "txtStringno"
        Me.txtStringno.Size = New System.Drawing.Size(100, 20)
        Me.txtStringno.TabIndex = 6
        '
        'txtReversestr
        '
        Me.txtReversestr.Location = New System.Drawing.Point(139, 73)
        Me.txtReversestr.Name = "txtReversestr"
        Me.txtReversestr.Size = New System.Drawing.Size(103, 20)
        Me.txtReversestr.TabIndex = 7
        '
        'txtBin
        '
        Me.txtBin.Location = New System.Drawing.Point(139, 106)
        Me.txtBin.Name = "txtBin"
        Me.txtBin.Size = New System.Drawing.Size(100, 20)
        Me.txtBin.TabIndex = 8
        '
        'ModuleEx
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 290)
        Me.Controls.Add(Me.txtBin)
        Me.Controls.Add(Me.txtReversestr)
        Me.Controls.Add(Me.txtStringno)
        Me.Controls.Add(Me.btndectobin)
        Me.Controls.Add(Me.btnpalindrom)
        Me.Controls.Add(Me.btnreverse)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "ModuleEx"
        Me.Text = "ModuleEx"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnreverse As System.Windows.Forms.Button
    Friend WithEvents btnpalindrom As System.Windows.Forms.Button
    Friend WithEvents btndectobin As System.Windows.Forms.Button
    Friend WithEvents txtStringno As System.Windows.Forms.TextBox
    Friend WithEvents txtReversestr As System.Windows.Forms.TextBox
    Friend WithEvents txtBin As System.Windows.Forms.TextBox
End Class
