﻿Public Class structex
    Structure Employee
        Dim empno As Integer
        Dim ename As String
        Dim salary As Double

        Sub New(ByVal empno As Integer, ByVal ename As String, ByVal salary As Double)
            Me.empno = empno
            Me.ename = ename
            Me.salary = salary
        End Sub

        Function getEmpno() As Integer
            Return empno
        End Function

        Function getEnm() As String
            Return ename
        End Function

        Function getSal() As Double
            Return salary
        End Function
    End Structure
    Private Sub btndisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndisplay.Click
        Dim e1 As New Employee(101, "Rajvi", 30000)
        txtempno.Text = e1.getEmpno
        txtempname.Text = e1.getEnm
        txtsal.Text = e1.getSal
    End Sub
End Class