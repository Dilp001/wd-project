﻿Public Class student_display

    Private Sub btndisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndisplay.Click
        Dim s As Student
        Dim sd As New StudDetail(txtrno.Text,txtname.Text,txtheight.Text,txtweight.Text)
        s = sd
        s.display()
    End Sub
End Class