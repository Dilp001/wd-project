﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ticketbooking
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCal = New System.Windows.Forms.Button()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtNooftickets = New System.Windows.Forms.TextBox()
        Me.lbl = New System.Windows.Forms.Label()
        Me.label = New System.Windows.Forms.Label()
        Me.chkSports = New System.Windows.Forms.CheckBox()
        Me.chkGame = New System.Windows.Forms.CheckBox()
        Me.chkSing = New System.Windows.Forms.CheckBox()
        Me.chkDance = New System.Windows.Forms.CheckBox()
        Me.rbWE = New System.Windows.Forms.RadioButton()
        Me.rbWD = New System.Windows.Forms.RadioButton()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCal
        '
        Me.btnCal.Location = New System.Drawing.Point(134, 241)
        Me.btnCal.Name = "btnCal"
        Me.btnCal.Size = New System.Drawing.Size(75, 23)
        Me.btnCal.TabIndex = 25
        Me.btnCal.Text = "Calculate"
        Me.btnCal.UseVisualStyleBackColor = True
        '
        'txtTotal
        '
        Me.txtTotal.Location = New System.Drawing.Point(134, 199)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(100, 20)
        Me.txtTotal.TabIndex = 24
        '
        'txtNooftickets
        '
        Me.txtNooftickets.Location = New System.Drawing.Point(134, 170)
        Me.txtNooftickets.Name = "txtNooftickets"
        Me.txtNooftickets.Size = New System.Drawing.Size(100, 20)
        Me.txtNooftickets.TabIndex = 23
        '
        'lbl
        '
        Me.lbl.AutoSize = True
        Me.lbl.Location = New System.Drawing.Point(48, 202)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(37, 13)
        Me.lbl.TabIndex = 22
        Me.lbl.Text = "Total :"
        '
        'label
        '
        Me.label.AutoSize = True
        Me.label.Location = New System.Drawing.Point(48, 170)
        Me.label.Name = "label"
        Me.label.Size = New System.Drawing.Size(80, 13)
        Me.label.TabIndex = 21
        Me.label.Text = "No. of Tickets :"
        '
        'chkSports
        '
        Me.chkSports.AutoSize = True
        Me.chkSports.Location = New System.Drawing.Point(173, 132)
        Me.chkSports.Name = "chkSports"
        Me.chkSports.Size = New System.Drawing.Size(71, 17)
        Me.chkSports.TabIndex = 20
        Me.chkSports.Text = "Sports-90"
        Me.chkSports.UseVisualStyleBackColor = True
        '
        'chkGame
        '
        Me.chkGame.AutoSize = True
        Me.chkGame.Location = New System.Drawing.Point(51, 132)
        Me.chkGame.Name = "chkGame"
        Me.chkGame.Size = New System.Drawing.Size(94, 17)
        Me.chkGame.TabIndex = 19
        Me.chkGame.Text = "GameZone-80"
        Me.chkGame.UseVisualStyleBackColor = True
        '
        'chkSing
        '
        Me.chkSing.AutoSize = True
        Me.chkSing.Location = New System.Drawing.Point(173, 103)
        Me.chkSing.Name = "chkSing"
        Me.chkSing.Size = New System.Drawing.Size(76, 17)
        Me.chkSing.TabIndex = 18
        Me.chkSing.Text = "Singing-50"
        Me.chkSing.UseVisualStyleBackColor = True
        '
        'chkDance
        '
        Me.chkDance.AutoSize = True
        Me.chkDance.Location = New System.Drawing.Point(51, 103)
        Me.chkDance.Name = "chkDance"
        Me.chkDance.Size = New System.Drawing.Size(81, 17)
        Me.chkDance.TabIndex = 17
        Me.chkDance.Text = "Dancing-40"
        Me.chkDance.UseVisualStyleBackColor = True
        '
        'rbWE
        '
        Me.rbWE.AutoSize = True
        Me.rbWE.Location = New System.Drawing.Point(173, 74)
        Me.rbWE.Name = "rbWE"
        Me.rbWE.Size = New System.Drawing.Size(99, 17)
        Me.rbWE.TabIndex = 16
        Me.rbWE.TabStop = True
        Me.rbWE.Text = "WeekEnds-100"
        Me.rbWE.UseVisualStyleBackColor = True
        '
        'rbWD
        '
        Me.rbWD.AutoSize = True
        Me.rbWD.Location = New System.Drawing.Point(50, 71)
        Me.rbWD.Name = "rbWD"
        Me.rbWD.Size = New System.Drawing.Size(91, 17)
        Me.rbWD.TabIndex = 15
        Me.rbWD.TabStop = True
        Me.rbWD.Text = "Weekdays-50"
        Me.rbWD.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(105, 35)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(48, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Name :"
        '
        'ticketbooking
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(321, 298)
        Me.Controls.Add(Me.btnCal)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.txtNooftickets)
        Me.Controls.Add(Me.lbl)
        Me.Controls.Add(Me.label)
        Me.Controls.Add(Me.chkSports)
        Me.Controls.Add(Me.chkGame)
        Me.Controls.Add(Me.chkSing)
        Me.Controls.Add(Me.chkDance)
        Me.Controls.Add(Me.rbWE)
        Me.Controls.Add(Me.rbWD)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "ticketbooking"
        Me.Text = "ticketbooking"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCal As System.Windows.Forms.Button
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtNooftickets As System.Windows.Forms.TextBox
    Friend WithEvents lbl As System.Windows.Forms.Label
    Friend WithEvents label As System.Windows.Forms.Label
    Friend WithEvents chkSports As System.Windows.Forms.CheckBox
    Friend WithEvents chkGame As System.Windows.Forms.CheckBox
    Friend WithEvents chkSing As System.Windows.Forms.CheckBox
    Friend WithEvents chkDance As System.Windows.Forms.CheckBox
    Friend WithEvents rbWE As System.Windows.Forms.RadioButton
    Friend WithEvents rbWD As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
