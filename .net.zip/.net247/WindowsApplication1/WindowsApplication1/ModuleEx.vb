﻿Public Class ModuleEx

    Private Sub btnreverse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreverse.Click
        Dim strrev As String = " "
        strrev = Conversion.ReverseString(txtStringno.Text)
        txtReversestr.Text = strrev
    End Sub

    Private Sub btnpalindrom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpalindrom.Click
        Dim chkpalin As String = " "
        chkpalin = Conversion.palindrom(txtStringno.Text)
        MessageBox.Show(chkpalin)
    End Sub

    Private Sub btndectobin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndectobin.Click
        Dim bin As String = " "
        bin = Conversion.decTobin(txtStringno.Text)
        txtBin.Text = bin
    End Sub
End Class