﻿
Imports System.String
Imports System.Math

Public Class calculator
    Dim opt As Integer = 0
    Dim a As Double = 0
    Dim optr As String = ""

    Private Sub btnclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclear.Click
        txt1.Clear()
        'txt1.text=" "
        a = 0
        opt = 0
        optr = ""
    End Sub
    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click, btn2.Click, btn3.Click, btn4.Click, btn5.Click, btn6.Click, btn7.Click, btn8.Click, btn9.Click, btn0.Click, btndot.Click
        Dim btn As Button = sender
        GenerateNumber(btn.Text)
    End Sub

    Sub GenerateNumber(ByVal num As String)
        If opt = 0 Then
            txt1.Text = txt1.Text & num
        Else
            opt = 0
            a = Convert.ToDouble(txt1.Text)
            txt1.Text = num
        End If
    End Sub

    Sub calculate()
        Select Case optr
            Case "+"
                txt1.Text = Convert.ToString _
                    (a + Convert.ToDouble(txt1.Text))
            Case "-"
                txt1.Text = Convert.ToString _
                   (a - Convert.ToDouble(txt1.Text))
            Case "*"
                txt1.Text = Convert.ToString _
                   (a * Convert.ToDouble(txt1.Text))
            Case "/"
                txt1.Text = Convert.ToString _
                   (a / Convert.ToDouble(txt1.Text))
            Case "Mod"
                txt1.Text = Convert.ToString _
                   (a Mod Convert.ToDouble(txt1.Text))
            Case "Sqrt"
                If txt1.Text <> 0 Then
                    txt1.Text = Convert.ToString _
                   (Sqrt(Convert.ToDouble(txt1.Text)))
                End If
        End Select
    End Sub


    Private Sub btnplus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnplus.Click
        opt = 1
        calculate()
        optr = "+"
    End Sub

    Private Sub btnminus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnminus.Click
        opt = 1
        calculate()
        optr = "-"
    End Sub

    Private Sub btnmul_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnmul.Click
        opt = 1
        calculate()
        optr = "*"
    End Sub

    Private Sub btndiv_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndiv.Click
        opt = 1
        calculate()
        optr = "/"
    End Sub

    Private Sub btnmode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnmode.Click
        opt = 1
        calculate()
        optr = "Mod"
    End Sub

    Private Sub btnsq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsq.Click
        opt = 1
        optr = "sqrt"
        calculate()
        optr = ""
    End Sub

    Private Sub btnbk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnbk.Click
        If txt1.Text <> " " Then
            Dim l As Integer = txt1.Text.Length
            txt1.Text = txt1.Text.Substring(0, l - 1)
        End If
    End Sub
End Class