<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mobile_number = $_POST['mobile_number'];
    $password = $_POST['password'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'perfume_store');
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = "SELECT * FROM users WHERE mobile_number = '$mobile_number'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_type'] = $row['user_type'];
            $_SESSION['mobile_number'] = $row['mobile_number'];
            
            if ($row['user_type'] == 'admin') {
                header("Location: admin_add_perfume.php");
            } else {
                header("Location: view_perfumes.php");
            }
            exit;
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with that mobile number.";
    }
    
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign In</title>
</head>
<body>
    <h1>Sign In</h1>
    <form method="POST">
        Mobile Number: <input type="text" name="mobile_number" required><br>
        Password: <input type="password" name="password" required><br>
        <button type="submit">Sign In</button>
    </form>
</body>
</html>