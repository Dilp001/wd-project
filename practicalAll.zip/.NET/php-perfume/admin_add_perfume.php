<?php
session_start();
if ($_SESSION['user_type'] != 'admin') {
    echo "Access Denied!";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $brand = $_POST['brand'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $stock = $_POST['stock'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'perfume_store');
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $sql = "INSERT INTO perfumes (name, brand, price, description, stock) 
            VALUES ('$name', '$brand', '$price', '$description', '$stock')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New perfume added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Perfume</title>
</head>
<body>
    <h1>Add New Perfume</h1>
    <form method="POST">
        Name: <input type="text" name="name" required><br>
        Brand: <input type="text" name="brand" required><br>
        Price: <input type="number" step="0.01" name="price" required><br>
        Description: <textarea name="description" required></textarea><br>
        Stock: <input type="number" name="stock" required><br>
        <button type="submit">Add Perfume</button>
    </form>
</body>
</html>