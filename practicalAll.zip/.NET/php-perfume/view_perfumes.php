<?php
session_start();
if (!isset($_SESSION['mobile_number'])) {
    echo "Please sign in to view perfumes.";
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'perfume_store');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM perfumes";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>View Perfumes</title>
</head>
<body>
    <h1>All Perfumes</h1>
    <table border="1">
        <tr>
            <th>Name</th>
            <th>Brand</th>
            <th>Price</th>
            <th>Description</th>
            <th>Stock</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$row['brand']}</td>
                        <td>{$row['price']}</td>
                        <td>{$row['description']}</td>
                        <td>{$row['stock']}</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No perfumes found</td></tr>";
        }
        ?>
    </table>
</body>
</html>

<?php
$conn->close();
?>