﻿Imports Microsoft.VisualBasic
Imports System.Data.OleDb
Imports System.Data

Public Class Student
    Dim cn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\tybca163\StudMgtSystem\StudMgtSystem\studb.accdb")
    Dim cm As OleDbCommand
    Dim da As OleDbDataAdapter
    Dim ds As New DataSet

    Public Sub IUD(ByVal str As String)
        If cn.State = ConnectionState.Closed Then
            cn.Open()
        End If

        cm = New OleDbCommand(str, cn)
        cm.ExecuteNonQuery()
        cn.Close()

    End Sub

    Public Function Display(ByVal str As String) As DataSet
        'Disconnected Model

        da = New OleDbDataAdapter(str, cn)
        ds.Tables.Clear()
        da.Fill(ds)
        Return ds
    End Function
End Class
