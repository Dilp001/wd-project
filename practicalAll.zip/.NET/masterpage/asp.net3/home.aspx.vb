﻿
Partial Class home
    Inherits System.Web.UI.Page

End Class
