﻿Imports System.Data.OleDb
Imports System.Data

Partial Class StudMastSimple
    Inherits System.Web.UI.Page

    Dim ds As New DataSet
    Dim s1 As New Student

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            FillCourseData()
            FillStudData()
        End If

    End Sub

    Private Sub FillCourseData()
        ds = s1.Display("select * from CourseMast")
        ddlCourse.DataSource = ds
        ddlCourse.DataTextField = "CName"
        ddlCourse.DataValueField = "CourseId"
        ddlCourse.DataBind()
    End Sub

    Private Sub FillStudData()
        ds = s1.Display("select s.RNo,s.SName,s.Address,s.Phone,s.Email,s.Gender,c.CName from StudMast s,CourseMast c where c.CourseId=s.CourseId order by RNo")
        GridView1.DataSource = ds
        GridView1.DataBind()
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        s1.IUD("Insert into StudMast values(" & txtRNo.Text & ",'" & txtName.Text & "','" & txtAdd.Text & "','" & txtPhone.Text & "','" & _
                   txtEmail.Text & "','" & rblGender.SelectedValue & "'," & ddlCourse.SelectedValue & ")")

        Response.Redirect("~/StudMastSimple.aspx")
    End Sub

    Protected Sub btnUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        s1.IUD("Update StudMast set SName='" & txtName.Text & "',Address='" & txtAdd.Text & "',Phone='" & txtPhone.Text & "',Email='" & _
                   txtEmail.Text & "',Gender='" & rblGender.SelectedValue & "',CourseId=" & ddlCourse.SelectedValue & " where RNo=" & txtRNo.Text)

        Response.Redirect("~/StudMastSimple.aspx")
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        s1.IUD("Delete from StudMast where RNo=" & txtRNo.Text)

        Response.Redirect("~/StudMast.aspx")
    End Sub

    Protected Sub btnGetData_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGetData.Click
        ds = s1.Display("select RNo,SName,Address,Phone,Email,Gender,CourseId from StudMast where RNo=" & txtRNo.Text & " order by RNo")

        txtRNo.Enabled = False
        txtName.Text = ds.Tables(0).Rows(0).Item("SName").ToString
        txtAdd.Text = ds.Tables(0).Rows(0).Item("Address").ToString
        txtPhone.Text = ds.Tables(0).Rows(0).Item("Phone").ToString
        txtEmail.Text = ds.Tables(0).Rows(0).Item("Email").ToString
        rblGender.SelectedValue = ds.Tables(0).Rows(0).Item("Gender").ToString
        ddlCourse.SelectedValue = ds.Tables(0).Rows(0).Item("CourseId").ToString
    End Sub
End Class
