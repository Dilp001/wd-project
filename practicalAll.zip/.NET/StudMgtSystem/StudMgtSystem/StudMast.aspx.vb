﻿Imports System.Data.OleDb
Imports System.Data

Partial Class StudMast
    Inherits System.Web.UI.Page

    Dim ds As New DataSet
    Dim s1 As New Student

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            FillCourseData()
            FillStudData()

            If Not Request.QueryString("RNo") Is Nothing Then
                Dim pRNo As Integer = Convert.ToInt64(Request.QueryString("RNo").ToString())
                ds = s1.Display("select RNo,SName,Address,Phone,Email,Gender,CourseId from StudMast where RNo=" & pRNo & " order by RNo")

                txtRNo.Text = pRNo
                txtRNo.Enabled = False
                txtName.Text = ds.Tables(0).Rows(0).Item("SName").ToString
                txtAdd.Text = ds.Tables(0).Rows(0).Item("Address").ToString
                txtPhone.Text = ds.Tables(0).Rows(0).Item("Phone").ToString
                txtEmail.Text = ds.Tables(0).Rows(0).Item("Email").ToString
                rblGender.SelectedValue = ds.Tables(0).Rows(0).Item("Gender").ToString
                ddlCourse.SelectedValue = ds.Tables(0).Rows(0).Item("CourseId").ToString
                btnAdd.Text = "Update"

            Else
                btnAdd.Text = "Add"
            End If
        End If
    End Sub

    Private Sub FillCourseData()
        ds = s1.Display("select * from CourseMast")
        ddlCourse.DataSource = ds
        ddlCourse.DataTextField = "CName"
        ddlCourse.DataValueField = "CourseId"
        ddlCourse.DataBind()
    End Sub

    Private Sub FillStudData()
        ds = s1.Display("select s.RNo,s.SName,s.Address,s.Phone,s.Email,s.Gender,c.CName from StudMast s,CourseMast c where c.CourseId=s.CourseId order by RNo")
        GridView1.DataSource = ds
        GridView1.DataBind()
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        If btnAdd.Text = "Add" Then
            s1.IUD("Insert into StudMast values(" & txtRNo.Text & ",'" & txtName.Text & "','" & txtAdd.Text & "','" & txtPhone.Text & "','" & _
                   txtEmail.Text & "','" & rblGender.SelectedValue & "'," & ddlCourse.SelectedValue & ")")
        Else
            s1.IUD("Update StudMast set SName='" & txtName.Text & "',Address='" & txtAdd.Text & "',Phone='" & txtPhone.Text & "',Email='" & _
                   txtEmail.Text & "',Gender='" & rblGender.SelectedValue & "',CourseId=" & ddlCourse.SelectedValue & " where RNo=" & txtRNo.Text)
        End If
        Response.Redirect("~/StudMast.aspx")
    End Sub

    Protected Sub lbDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim l As LinkButton = sender
        Dim pRNo As Integer = Convert.ToInt16(l.CommandArgument)
        s1.IUD("Delete from StudMast where RNo=" & pRNo)
        Response.Redirect("~/StudMast.aspx")
    End Sub

End Class
